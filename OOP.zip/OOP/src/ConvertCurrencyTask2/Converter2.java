/*package ConvertCurrencyTask2;

public class Converter2 {

    private double usd = 1;
    private double euro = 0.89;
    private double uah = 26.18;
    private double jpy = 109.94;
    private double pound = 0.77;
    private int usersSum;
    private stringTask currency;
    private double rate;
    private int currencyConverter;

    public Converter2 (stringTask currency,double rate) {
        this.currency = currency;
        this.rate = rate;
    }





    public double getUsd() {
        return usd;
    }

    public double getEuro() {
        return euro;
    }

    public double getUah() {
        return uah;
    }

    public double getJpy() {
        return jpy;
    }

    public double getPound() {
        return pound;
    }

    public void setUsersSum (int usersSum) {
        this.usersSum = usersSum;

        switch (currency) {
            case "USD":
                currencyConverter = usersSum*;
                break;
            case "EURO":
                currencyConverter = (usersSum/euro);
                break;
            case "UAH":
                currencyConverter = getData.multiply();
                break;
            case "JPY":
                currencyConverter = getData.divide();
                break;
            case "POUND":
                currencyConverter = getData.divide();
                break;
        }
    }








}*/
