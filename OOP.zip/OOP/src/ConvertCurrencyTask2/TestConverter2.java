/*package ConvertCurrencyTask2;


import java.util.Scanner;
public class TestConverter2 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter sum and currency you wand to exchange");
        int sumToExchange = scanner.nextInt();
        String currencyToExchange = scanner.next();
        System.out.println("what currency do you want to convert?");
        String choosenCurrency = scanner.next();



        Converter2[] currencies = {
                new Converter2("USD", 1.0),
                new Converter2("EURO", 0.89),
                new Converter2("UAH", 26.18),
                new Converter2("JPY", 109.94),
                new Converter2("POUND", 0.77),
        };


    }
}*/
