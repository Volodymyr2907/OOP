package digitSum;


import java.util.Scanner;
public class DigitSum {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int userInput = scanner.nextInt();
        for(int i = 1; i <= userInput; ++i)
        {
            // sum = sum + i;
            userInput += i;
        }

        System.out.println("Sum = " + userInput);



    }
}
